
# 传递参数给 pfind 程序
/home/io500/HPFS/pfind/test_correct/test_correct "$@"