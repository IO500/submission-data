#include <sys/ioctl.h>
#include "syscall_handlers.h"
#include <cstring>

#define FD INT16_MAX
#define FIND_CMD INT16_MAX

int main(int argc, char* argv[]) {
    findreq* req = new findreq {
        .workdir = NULL,
        .timestamp_file = NULL,
        .size = UINT64_MAX,
        .pattern = NULL,
        .res = new findres()
    };
    for (int i=1;i<argc-1;i++) {
        if(strcmp(argv[i], "-newer") == 0) {
            req->timestamp_file = strdup(argv[i+1]);
            argv[i][0] = 0;
            argv[++i][0] = 0;
        }
        else if(strcmp(argv[i], "-size") == 0){
            char *str = argv[i+1];
            char extension = str[strlen(str)-1];
            str[strlen(str)-1] = 0;
            req->size = atoll(str);
            if (extension!='c') {
                printf("Unsupported exension for -size\n");
                return 0;
            }
            argv[i][0] = 0;
            argv[++i][0] = 0;
        }
        else if(strcmp(argv[i], "-name") == 0){
          req->pattern = (const char*) malloc(strlen(argv[i+1])*4+100);
          // transform a traditional name pattern to a regex:
          char * str = argv[i+1];
          char * out = (char*)req->pattern;
          int pos = 0;
          for(unsigned i=0; i < strlen(str); i++){
            if(str[i] == '*'){
              pos += sprintf(out + pos, ".*");
            }else if(str[i] == '.'){
              pos += sprintf(out + pos, "[.]");
            }else if(str[i] == '"' || str[i] == '\"'){
              // erase the "
            }else{
              out[pos] = str[i];
              pos++;
            }
          }
          out[pos] = 0;
          argv[i][0] = 0;
          argv[++i][0] = 0;
        }
        else if(strcmp(argv[i], "-regex") == 0){
          req->pattern = strdup(argv[i+1]);
          argv[i][0] = 0;
          argv[++i][0] = 0;
        }
        else if(req->workdir == NULL){
          req->workdir = strdup(argv[i]);
          argv[i][0] = 0;
        }
    }
    if(argc == 2){
        req->workdir = strdup(argv[1]);
    }
    ioctl(FD, FIND_CMD, (uint64_t)req);
    printf("MATCHED %lu/%lu\n", req->res->found_file, req->res->total_file);
    return 0;
}