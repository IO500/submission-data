#!/bin/bash

while read -r host; do
  ssh -n root@$host "cd /home/huyk/huyk-workspace/darkstore/build && bash ./dark_server " >../log/$$.${host}.log 2>&1 &
done < my-server.txt

cd /home/huyk/huyk-workspace/io500/
./io500 config-scc.ini

