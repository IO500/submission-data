#ifndef DARKSTORE_SYSCALL_HANDLERS_H__
#define DARKSTORE_SYSCALL_HANDLERS_H__

#include <cstdint>
#include <string>
#include <sys/stat.h>
#include <sys/statfs.h>
#include <sys/types.h>

using std::string;

struct findres {
  uint64_t total_file;
  uint64_t found_file;
};

struct findreq {
  const char *workdir;
  const char *timestamp_file;
  uint64_t size;
  const char *pattern;
  findres *res;
};

void HandleFsync(const char *path);
void HandleAccess(const char *path);
void HandleOpenat(const char *path);
void HandleUnlink(const char *path);
int HandleRead(const char *path, char *buf, int size, uint64_t offset);
int HandleWrite(const char *path, const char *buf, int size, uint64_t offset);
void HandleStat(const char *path, struct stat *statbuf);
void HandleStatfs(struct statfs *buf);
void HandleFind(findreq *req);

#endif // !DARKSTORE_SYSCALL_HANDLERS_H__
